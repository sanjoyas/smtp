<?php
use PHPMailer\PHPMailer\PHPMailer;
require_once "PHPMailere/autoload.php";

$mail = new PHPMailer();

//Enable SMTP debugging. 
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "majipartha123bca@gmail.com";                 
$mail->Password = "9641873108@";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "ssl";                           
//Set TCP port to connect to 
$mail->Port = 465;                                   

$mail->From = "majipartha123bca@gmail.com";
$mail->FromName = "Sanjoy Patra";

$mail->addAddress("patrasanjoy101@gmail.com", "Sanjoy Patra");

$mail->isHTML(true);

$mail->Subject = "Subject Text";
$mail->Body = "<i>Mail body in HTML</i>";
$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;

} 
else 
{   
    echo "Message has been sent successfully";
    $_SESSION["status"] = "S";
    header("Location: index.php"); 
    exit();
}