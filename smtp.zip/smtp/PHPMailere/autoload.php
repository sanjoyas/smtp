<?php
    session_start();
    require_once("src/PHPMailer.php");
    require_once("src/SMTP.php");
    require_once("src/Exception.php");
    //require_once("src/OAuth.php");
    //require_once("src/POP3.php");
?>