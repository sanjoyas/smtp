<?php
 $test = 'Hi';
?>